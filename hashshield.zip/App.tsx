
import React, { useState } from 'react';
import { AppView } from './types';
import { KdfInfo } from './components/KdfInfo';
import { ImplementationAudit } from './components/ImplementationAudit';
import { HashMigration } from './components/HashMigration';
import { ShaStandards } from './components/ShaStandards';
import { TabSelector } from './components/TabSelector';
import { ShieldCheckIcon, WrenchScrewdriverIcon, ArrowPathIcon, FingerPrintIcon } from './constants';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<AppView>(AppView.KDFInfo);

  const tabs = [
    { view: AppView.KDFInfo, label: 'Moderné KDF', icon: <ShieldCheckIcon /> },
    { view: AppView.ImplementationAudit, label: 'Implementačný Audit', icon: <WrenchScrewdriverIcon /> },
    { view: AppView.HashMigration, label: 'Migrácia Hašov', icon: <ArrowPathIcon /> },
    { view: AppView.ShaStandards, label: 'Štandardy SHA', icon: <FingerPrintIcon /> },
  ];

  const renderContent = () => {
    switch (activeView) {
      case AppView.KDFInfo:
        return <KdfInfo />;
      case AppView.ImplementationAudit:
        return <ImplementationAudit />;
      case AppView.HashMigration:
        return <HashMigration />;
      case AppView.ShaStandards:
        return <ShaStandards />;
      default:
        return <KdfInfo />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-300 font-sans">
      <header className="bg-slate-900/70 backdrop-blur-lg border-b border-slate-800 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center">
          <ShieldCheckIcon className="h-8 w-8 text-cyan-400 mr-3"/>
          <h1 className="text-2xl font-bold text-white tracking-tight">HashShield</h1>
          <span className="ml-4 text-xs bg-cyan-500/20 text-cyan-400 font-semibold px-2 py-1 rounded-full">Nástroj na Bezpečnosť Hesiel</span>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <TabSelector activeView={activeView} setActiveView={setActiveView} tabs={tabs} />
        <div>
          {renderContent()}
        </div>
      </main>

      <footer className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center text-sm text-slate-500 border-t border-slate-800 mt-10">
        <p>&copy; {new Date().getFullYear()} HashShield. Vytvorené na edukáciu a presadzovanie osvedčených postupov v oblasti bezpečnosti.</p>
      </footer>
    </div>
  );
};

export default App;
