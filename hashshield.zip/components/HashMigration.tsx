
import React, { useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

const migrationData = [
  { name: 'MD5/SHA1 (Zraniteľné)', value: 400 },
  { name: 'SHA-256 (Nesolené)', value: 300 },
  { name: 'Bcrypt (Bezpečné)', value: 200 },
  { name: 'Argon2 (Moderné)', value: 100 },
];

const COLORS = ['#ef4444', '#f97316', '#3b82f6', '#14b8a6'];

export const HashMigration: React.FC = () => {
    const [migratedPercent, setMigratedPercent] = useState(30);

    const data = [
        { name: 'Migrované na Argon2', value: migratedPercent },
        { name: 'Zostávajúce staré haše', value: 100 - migratedPercent },
    ];

    return (
        <div className="animate-fade-in">
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl mb-4">Migrácia Hašov</h2>
            <p className="text-lg text-slate-400 mb-8">
                Poskytuje bezpečný spôsob, ako postupne presunúť heslá zo starých, zraniteľných schém (MD5, SHA1) na moderné (Argon2) bez nutnosti resetovania hesla používateľom.
            </p>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-slate-800/50 p-6 rounded-lg ring-1 ring-slate-700">
                    <h3 className="text-xl font-bold text-white mb-4">Proces Migrácie</h3>
                    <ol className="list-decimal list-inside space-y-4 text-slate-300">
                        <li>
                            <strong className="text-white">Detekcia Zraniteľnosti:</strong>
                            <p className="text-sm text-slate-400 pl-2">Systém identifikuje staré haše (napr. MD5, SHA1, alebo nesolený SHA-256) v databáze.</p>
                        </li>
                        <li>
                            <strong className="text-white">Línia Migrácie (On-the-fly):</strong>
                            <p className="text-sm text-slate-400 pl-2">Keď sa používateľ prihlási, systém overí jeho heslo pomocou starého hašu. Ak je prihlásenie úspešné, systém okamžite vytvorí nový, bezpečný haš pomocou Argon2.</p>
                        </li>
                        <li>
                            <strong className="text-white">Aktualizácia Databázy:</strong>
                            <p className="text-sm text-slate-400 pl-2">Nový Argon2 haš nahradí starý v databáze. Pri ďalšom prihlásení sa už použije moderný algoritmus.</p>
                        </li>
                         <li>
                            <strong className="text-white">Audit a Reporting:</strong>
                            <p className="text-sm text-slate-400 pl-2">Pravidelné sledovanie, koľko percent databázy už bolo úspešne migrovaných na bezpečnú schému.</p>
                        </li>
                    </ol>
                </div>
                <div className="bg-slate-800/50 p-6 rounded-lg ring-1 ring-slate-700">
                    <h3 className="text-xl font-bold text-white mb-4">Simulácia Auditu a Reportingu</h3>
                    <p className="text-sm text-slate-400 mb-4">Upravte posuvník na simuláciu postupnej migrácie používateľov na nový hašovací algoritmus.</p>
                     <div className="h-64 w-full">
                        <ResponsiveContainer>
                            <PieChart>
                                <Pie
                                    data={data}
                                    cx="50%"
                                    cy="50%"
                                    labelLine={false}
                                    outerRadius={80}
                                    fill="#8884d8"
                                    dataKey="value"
                                    label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}
                                >
                                    <Cell key={`cell-0`} fill={COLORS[3]} />
                                    <Cell key={`cell-1`} fill={COLORS[0]} />
                                </Pie>
                                <Tooltip formatter={(value: number, name: string) => [`${value}%`, name]}/>
                                <Legend />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                    <div className="mt-4">
                        <label htmlFor="migrationRange" className="block text-sm font-medium text-slate-300">Percento migrovaných účtov: {migratedPercent}%</label>
                        <input
                            type="range"
                            id="migrationRange"
                            min="0"
                            max="100"
                            value={migratedPercent}
                            onChange={(e) => setMigratedPercent(Number(e.target.value))}
                            className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};
