
import React, { useState, useCallback } from 'react';
import { generateSalt, verifyArgon2Format, verifyBcryptFormat } from '../services/cryptoService';

const SaltGenerator: React.FC = () => {
    const [salt, setSalt] = useState('');
    const handleGenerate = useCallback(() => {
        setSalt(generateSalt(16));
    }, []);

    return (
        <div className="bg-slate-800/50 p-6 rounded-lg ring-1 ring-slate-700">
            <h3 className="text-lg font-semibold text-white mb-2">1. Salt Generator</h3>
            <p className="text-sm text-slate-400 mb-4">Generuje kryptograficky silnú, jedinečnú soľ (salt) pre každé heslo, čím bráni útokom typu "Rainbow Table". Odporúčaná dĺžka je 16 bajtov (32 hex znakov).</p>
            <div className="flex items-center space-x-4">
                <input type="text" readOnly value={salt} placeholder="Kliknite na 'Generovať'" className="flex-grow bg-slate-900 border border-slate-600 rounded-md px-3 py-2 text-slate-300 focus:ring-cyan-500 focus:border-cyan-500 font-mono text-sm" />
                <button onClick={handleGenerate} className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2 px-4 rounded-md transition-colors duration-200">Generovať</button>
            </div>
        </div>
    );
};

const CostAnalyzer: React.FC = () => {
    const [cost, setCost] = useState(12);
    const [duration, setDuration] = useState<number | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleBenchmark = () => {
        setIsLoading(true);
        setDuration(null);
        // Simulate benchmark based on cost factor. This is a frontend simulation.
        const simulatedTime = 50 * Math.pow(1.5, cost - 10);
        setTimeout(() => {
            setDuration(simulatedTime);
            setIsLoading(false);
        }, simulatedTime);
    };

    return (
        <div className="bg-slate-800/50 p-6 rounded-lg ring-1 ring-slate-700">
            <h3 className="text-lg font-semibold text-white mb-2">2. Cost Factor / Iterations Analyzer</h3>
            <p className="text-sm text-slate-400 mb-4">Analyzuje a navrhuje optimálny počet iterácií (časový faktor), aby overenie jedného hesla trvalo približne 0.5 sekundy. Tým sa extrémne zvyšujú náklady na útok hrubou silou. (Toto je simulácia pre Bcrypt cost factor)</p>
            <div className="flex items-center space-x-4 mb-4">
                <label htmlFor="cost" className="text-sm font-medium text-slate-300">Bcrypt Cost Factor:</label>
                <input type="range" id="cost" min="8" max="16" value={cost} onChange={(e) => setCost(Number(e.target.value))} className="w-48" />
                <span className="font-mono text-cyan-400">{cost}</span>
                <button onClick={handleBenchmark} disabled={isLoading} className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2 px-4 rounded-md transition-colors duration-200 disabled:bg-slate-500 disabled:cursor-not-allowed">
                    {isLoading ? 'Benchmarking...' : 'Spustiť Benchmark'}
                </button>
            </div>
            {duration !== null && (
                 <div className={`p-3 rounded-md text-sm ${duration > 400 && duration < 600 ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'}`}>
                    Simulované trvanie: <span className="font-bold">{duration.toFixed(0)} ms</span>. 
                    {duration > 400 && duration < 600 ? ' Ideálny parameter!' : ' Zvážte úpravu parametra, aby ste sa priblížili k 500 ms.'}
                </div>
            )}
        </div>
    );
};

const FormatVerifier: React.FC = () => {
    const [hashInput, setHashInput] = useState('');
    const [verificationResult, setVerificationResult] = useState<string | null>(null);

    const handleVerify = () => {
        if (!hashInput) {
            setVerificationResult(null);
            return;
        }
        if (verifyArgon2Format(hashInput)) {
            setVerificationResult('Platný formát Argon2');
        } else if (verifyBcryptFormat(hashInput)) {
            setVerificationResult('Platný formát Bcrypt');
        } else {
            setVerificationResult('Neplatný alebo nerozpoznaný formát');
        }
    };

    return (
        <div className="bg-slate-800/50 p-6 rounded-lg ring-1 ring-slate-700">
            <h3 className="text-lg font-semibold text-white mb-2">3. Verifikátor Formátu</h3>
            <p className="text-sm text-slate-400 mb-4">Kontroluje, či je haš uložený v správnom formáte, ktorý zahŕňa algoritmus, soľ a faktor nákladov. Toto je kľúčové pre budúcu verifikáciu a migráciu.</p>
            <div className="flex items-center space-x-4">
                <input type="text" value={hashInput} onChange={(e) => setHashInput(e.target.value)} placeholder="Vložte haš na overenie..." className="flex-grow bg-slate-900 border border-slate-600 rounded-md px-3 py-2 text-slate-300 focus:ring-cyan-500 focus:border-cyan-500 font-mono text-sm" />
                <button onClick={handleVerify} className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2 px-4 rounded-md transition-colors duration-200">Overiť</button>
            </div>
             {verificationResult && (
                <p className={`mt-3 text-sm font-semibold ${verificationResult.startsWith('Platný') ? 'text-green-400' : 'text-red-400'}`}>
                    {verificationResult}
                </p>
            )}
        </div>
    );
};

export const ImplementationAudit: React.FC = () => {
  return (
    <div className="animate-fade-in">
        <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl mb-4">Implementačný Audit</h2>
        <p className="text-lg text-slate-400 mb-8">
            Tieto nástroje vám pomôžu overiť, či vaša implementácia hašovania spĺňa osvedčené postupy (Best Practices) pre maximálnu bezpečnosť.
        </p>
        <div className="space-y-8">
            <SaltGenerator />
            <CostAnalyzer />
            <FormatVerifier />
        </div>
    </div>
  );
};
