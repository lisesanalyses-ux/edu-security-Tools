
import React from 'react';

const KdfCard: React.FC<{ title: string; subtitle: string; children: React.ReactNode; recommended?: boolean }> = ({ title, subtitle, children, recommended }) => (
  <div className={`bg-slate-800/50 rounded-lg shadow-lg ring-1 ring-slate-700 overflow-hidden ${recommended ? 'ring-cyan-500/50' : ''}`}>
    <div className={`p-6 border-b border-slate-700 ${recommended ? 'bg-cyan-500/10' : ''}`}>
      <h3 className="text-xl font-bold text-white">{title}</h3>
      <p className="text-sm text-cyan-400 font-semibold">{subtitle}</p>
    </div>
    <div className="p-6 text-slate-300 space-y-4">
      {children}
    </div>
  </div>
);

export const KdfInfo: React.FC = () => {
  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl mb-4">Moderné Hašovacie Algoritmy (KDF)</h2>
      <p className="text-lg text-slate-400 mb-8">
        Pre bezpečné ukladanie hesiel je kľúčové používať špeciálne navrhnuté KDF (Key Derivation Functions) algoritmy, nie štandardné hašovacie funkcie ako SHA-256. KDF sú zámerne pomalé a náročné na zdroje, aby sa maximalizovali náklady na útoky hrubou silou.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <KdfCard title="Argon2" subtitle="Odporúčaný Moderný Štandard" recommended>
          <p>Víťaz súťaže Password Hashing Competition (PHC), Argon2 je navrhnutý tak, aby bol odolný voči útokom pomocou GPU a ASIC hardvéru.</p>
          <div>
            <h4 className="font-semibold text-white mb-2">Kľúčové Vlastnosti:</h4>
            <ul className="list-disc list-inside space-y-1 text-slate-400">
              <li><strong>Náročnosť na pamäť:</strong> Bráni paralelizácii útoku na špecializovanom hardvéri.</li>
              <li><strong>Nastaviteľné parametre:</strong> Umožňuje jemné doladenie náročnosti (pamäť, čas, paralelizmus).</li>
              <li><strong>Tri varianty:</strong> Argon2d (odolný voči GPU), Argon2i (odolný voči side-channel útokom) a Argon2id (hybridný, odporúčaný).</li>
            </ul>
          </div>
        </KdfCard>
        <KdfCard title="Bcrypt" subtitle="Starší, ale Stále Spoľahlivý">
          <p>Bcrypt je osvedčený a široko používaný algoritmus, ktorý je na scéne už od roku 1999. Je založený na šifre Blowfish.</p>
          <div>
            <h4 className="font-semibold text-white mb-2">Kľúčové Vlastnosti:</h4>
            <ul className="list-disc list-inside space-y-1 text-slate-400">
              <li><strong>Adaptívna funkcia:</strong> Náročnosť sa dá zvyšovať pomocou "cost factor".</li>
              <li><strong>Pomalosť:</strong> Overenie jedného hesla je zámerne pomalé.</li>
              <li><strong>Vstavaná soľ (salt):</strong> Automaticky generuje a spravuje soľ.</li>
            </ul>
          </div>
        </KdfCard>
      </div>
    </div>
  );
};
