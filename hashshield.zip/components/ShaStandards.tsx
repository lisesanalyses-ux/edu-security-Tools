
import React, { useState, useCallback } from 'react';
import { hashFile } from '../services/cryptoService';

export const ShaStandards: React.FC = () => {
    const [file, setFile] = useState<File | null>(null);
    const [fileHash, setFileHash] = useState<string>('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string>('');

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files.length > 0) {
            setFile(event.target.files[0]);
            setFileHash('');
            setError('');
        }
    };

    const handleHashFile = useCallback(async () => {
        if (!file) {
            setError('Prosím, vyberte súbor.');
            return;
        }
        setIsLoading(true);
        setError('');
        setFileHash('');
        try {
            // Note: Web Crypto API doesn't support SHA-3. We'll use SHA-256 and mention this limitation.
            const hash = await hashFile(file, 'SHA-256');
            setFileHash(hash);
        } catch (err) {
            setError('Nastala chyba pri hašovaní súboru.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, [file]);

    return (
        <div className="animate-fade-in">
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl mb-4">Štandardy SHA-256 a SHA-3 (Keccak)</h2>
            <p className="text-lg text-slate-400 mb-8">
                Tieto algoritmy sú extrémne rýchle a efektívne, čo ich robí ideálnymi pre integritu dát, ale <strong className="text-yellow-400">nevhodnými pre ukladanie hesiel</strong>. Ich rýchlosť by umožnila útočníkovi otestovať miliardy hesiel za sekundu.
            </p>
            <div className="bg-slate-800/50 p-6 rounded-lg ring-1 ring-slate-700">
                <h3 className="text-xl font-bold text-white mb-4">Správne Použitie</h3>
                <ul className="list-disc list-inside space-y-2 text-slate-300 mb-6">
                    <li><strong>Integrita súborov (SHA-256/SHA-3):</strong> Kontrola, či súbor nebol zmenený alebo poškodený (napr. pri sťahovaní, zálohovaní alebo ukladaní logov).</li>
                    <li><strong>Digitálne podpisy:</strong> Overenie autenticity a integrity dokumentov a správ.</li>
                    <li><strong>Generovanie kľúčov:</strong> Použitie ako súčasť pseudo-náhodného generátora (PRNG) na generovanie kľúčov pre šifrovanie.</li>
                </ul>

                <h3 className="text-lg font-semibold text-white mb-2">Nástroj na Overenie Integrity Súborov</h3>
                <p className="text-sm text-slate-400 mb-4">Nahrajte súbor a vypočítajte jeho SHA-256 haš na overenie jeho integrity. Váš súbor sa nikam neodosiela, spracovanie prebieha lokálne vo vašom prehliadači.</p>

                <div className="flex items-center space-x-4">
                    <input type="file" onChange={handleFileChange} className="block w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-cyan-600/20 file:text-cyan-300 hover:file:bg-cyan-600/30" />
                    <button onClick={handleHashFile} disabled={!file || isLoading} className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2 px-4 rounded-md transition-colors duration-200 disabled:bg-slate-500 disabled:cursor-not-allowed">
                        {isLoading ? 'Hašujem...' : 'Vypočítať Hash'}
                    </button>
                </div>
                {error && <p className="text-red-400 text-sm mt-2">{error}</p>}
                {fileHash && (
                    <div className="mt-4">
                        <p className="text-sm text-slate-300">SHA-256 Hash:</p>
                        <pre className="bg-slate-900 p-3 rounded-md text-cyan-400 font-mono text-sm break-all">{fileHash}</pre>
                        <p className="text-xs text-slate-500 mt-2">*Poznámka: Pre SHA-3 by bola potrebná externá kryptografická knižnica, pretože nie je súčasťou štandardného Web Crypto API.</p>
                    </div>
                )}
            </div>
        </div>
    );
};
