import React from 'react';
import { AppView } from '../types';

interface TabSelectorProps {
  activeView: AppView;
  setActiveView: (view: AppView) => void;
  // Fix: Use React.ReactElement instead of JSX.Element to resolve "Cannot find namespace 'JSX'" error.
  tabs: { view: AppView; label: string; icon: React.ReactElement }[];
}

export const TabSelector: React.FC<TabSelectorProps> = ({ activeView, setActiveView, tabs }) => {
  return (
    <div className="mb-8 border-b border-slate-700">
      <nav className="-mb-px flex space-x-6" aria-label="Tabs">
        {tabs.map((tab) => (
          <button
            key={tab.view}
            onClick={() => setActiveView(tab.view)}
            className={`${
              activeView === tab.view
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-500'
            } flex items-center whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-cyan-500 rounded-t-md`}
            aria-current={activeView === tab.view ? 'page' : undefined}
          >
            {React.cloneElement(tab.icon, { className: 'mr-2 h-5 w-5' })}
            {tab.label}
          </button>
        ))}
      </nav>
    </div>
  );
};