
export const generateSalt = (length: number = 16): string => {
  const array = new Uint8Array(length);
  window.crypto.getRandomValues(array);
  return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('');
};

export const hashFile = async (file: File, algorithm: 'SHA-256' | 'SHA-3-256' = 'SHA-256'): Promise<string> => {
  const arrayBuffer = await file.arrayBuffer();
  // Note: SHA-3 is not natively supported in Web Crypto API, so we will use SHA-256 for demonstration.
  // In a real application, a library like js-sha3 would be needed.
  const hashBuffer = await crypto.subtle.digest(algorithm, arrayBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
};

export const verifyArgon2Format = (hash: string): boolean => {
    // Example format: $argon2id$v=19$m=65536,t=2,p=1$SALT$HASH
    const argon2Regex = /^\$argon2(id?|d)\$v=\d+\$m=\d+,t=\d+,p=\d+\$[A-Za-z0-9+/]+={0,2}\$[A-Za-z0-9+/]+={0,2}$/;
    return argon2Regex.test(hash);
};

export const verifyBcryptFormat = (hash: string): boolean => {
    // Example format: $2a$10$SALT...HASH...
    const bcryptRegex = /^\$2[aby]?\$\d{2}\$[./A-Za-z0-9]{53}$/;
    return bcryptRegex.test(hash);
};
