
export enum AppView {
  KDFInfo = 'KDFInfo',
  ImplementationAudit = 'ImplementationAudit',
  HashMigration = 'HashMigration',
  ShaStandards = 'ShaStandards',
}
