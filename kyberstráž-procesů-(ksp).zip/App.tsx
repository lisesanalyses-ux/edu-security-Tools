
import React, { useState, useEffect, useCallback } from 'react';
import { Process, Alert as AlertType, RiskLevel } from './types';
import { processService } from './services/processService';
import Header from './components/Header';
import ProcessTreeView from './components/ProcessTreeView';
import ProcessDetailView from './components/ProcessDetailView';
import AlertModal from './components/AlertModal';

const App: React.FC = () => {
  const [processes, setProcesses] = useState<Process[]>([]);
  const [selectedProcess, setSelectedProcess] = useState<Process | null>(null);
  const [activeAlert, setActiveAlert] = useState<AlertType | null>(null);

  const checkForAnomalies = useCallback((updatedProcesses: Process[]) => {
    if (activeAlert) return;

    const anomaly = updatedProcesses.find(
      (p) =>
        p.isAnomaly &&
        !p.userAcknowledged &&
        (p.riskLevel === RiskLevel.Low || p.riskLevel === RiskLevel.Medium)
    );

    if (anomaly) {
      setActiveAlert({
        process: anomaly,
        message: `Proces ${anomaly.name} (PID: ${anomaly.pid}) vykazuje neobvyklou aktivitu.`,
        details: anomaly.anomalyReason || 'Nespecifikovaný důvod.',
      });
    }
  }, [activeAlert]);


  useEffect(() => {
    const initialProcesses = processService.getInitialProcesses();
    setProcesses(initialProcesses);
    checkForAnomalies(initialProcesses);

    const interval = setInterval(() => {
      setProcesses(prevProcesses => {
        const updatedProcesses = processService.updateProcesses(prevProcesses);
        checkForAnomalies(updatedProcesses);
        // if the selected process is updated, update the selection
        if (selectedProcess) {
            const updatedSelected = updatedProcesses.find(p => p.pid === selectedProcess.pid);
            if (updatedSelected) {
                setSelectedProcess(updatedSelected);
            } else {
                setSelectedProcess(null); // it was terminated
            }
        }
        return updatedProcesses;
      });
    }, 3000);

    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSelectProcess = (process: Process) => {
    setSelectedProcess(process);
  };

  const handleAlertResponse = (processId: number, response: 'allow' | 'good' | 'attack') => {
    setProcesses(prev =>
      prev.map(p => {
        if (p.pid === processId) {
          const updatedProcess = { ...p, userAcknowledged: true, isAnomaly: response !== 'attack' };
          if(response === 'good') updatedProcess.riskLevel = RiskLevel.None;
          if(response === 'attack') updatedProcess.riskLevel = RiskLevel.Critical;
          return updatedProcess;
        }
        return p;
      })
    );
    setActiveAlert(null);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 flex flex-col">
      <Header />
      <main className="flex-grow flex p-4 gap-4 overflow-hidden">
        <div className="w-full md:w-2/3 lg:w-3/4 flex-shrink-0 overflow-y-auto bg-gray-800 rounded-lg p-4 shadow-lg">
           <h2 className="text-xl font-bold mb-4 text-cyan-400 border-b border-gray-700 pb-2">Strom Procesů</h2>
          <ProcessTreeView processes={processes} onSelectProcess={handleSelectProcess} selectedProcessId={selectedProcess?.pid} />
        </div>
        <div className="w-full md:w-1/3 lg:w-1/4 flex-shrink-0 overflow-y-auto bg-gray-800 rounded-lg shadow-lg">
          <ProcessDetailView process={selectedProcess} />
        </div>
      </main>
      {activeAlert && (
        <AlertModal
          alert={activeAlert}
          onResponse={handleAlertResponse}
          onClose={() => setActiveAlert(null)}
        />
      )}
    </div>
  );
};

export default App;
