
import React from 'react';
import { Alert } from '../types';

interface AlertModalProps {
  alert: Alert;
  onResponse: (processId: number, response: 'allow' | 'good' | 'attack') => void;
  onClose: () => void;
}

const AlertModal: React.FC<AlertModalProps> = ({ alert, onResponse, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 transition-opacity">
      <div className="bg-gray-800 rounded-lg shadow-2xl p-6 w-full max-w-lg border-2 border-yellow-500 animate-fade-in-up">
        <div className="flex items-center mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-8 h-8 text-yellow-400 mr-3"><path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>
            <h2 className="text-xl font-bold text-yellow-400">Detekována Anomálie</h2>
        </div>
        
        <p className="mb-2 text-gray-300">{alert.message}</p>
        <div className="bg-gray-900 p-3 rounded mb-4">
            <p className="text-sm font-semibold text-gray-300">Důvod:</p>
            <p className="text-sm text-gray-400 italic">{alert.details}</p>
        </div>
        
        <p className="text-sm text-gray-200 mb-5">Jedná se o součást vaší legitimní pracovní aktivity, nebo jste tuto aktivitu neočekával/a?</p>
        
        <div className="flex justify-end space-x-3">
          <button
            onClick={() => onResponse(alert.process.pid, 'allow')}
            className="px-4 py-2 bg-gray-600 hover:bg-gray-500 text-white font-semibold rounded-lg transition-colors"
          >
            Povolit Jednou
          </button>
          <button
            onClick={() => onResponse(alert.process.pid, 'good')}
            className="px-4 py-2 bg-green-600 hover:bg-green-500 text-white font-semibold rounded-lg transition-colors"
          >
            Označit jako "Dobrý"
          </button>
          <button
            onClick={() => onResponse(alert.process.pid, 'attack')}
            className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-lg transition-colors"
          >
            Označit jako "Útok"
          </button>
        </div>
      </div>
    </div>
  );
};

export default AlertModal;
