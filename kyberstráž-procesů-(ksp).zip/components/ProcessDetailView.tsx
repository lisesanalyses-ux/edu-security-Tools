
import React from 'react';
import { Process, NetworkConnection, FileActivity, RiskLevel } from '../types';

const riskDetailMap: { [key in RiskLevel]: { text: string; bg: string; textCol: string } } = {
    [RiskLevel.None]: { text: 'Žádné', bg: 'bg-gray-600', textCol: 'text-gray-100' },
    [RiskLevel.Low]: { text: 'Nízké', bg: 'bg-yellow-600', textCol: 'text-yellow-100' },
    [RiskLevel.Medium]: { text: 'Střední', bg: 'bg-orange-500', textCol: 'text-orange-100' },
    [RiskLevel.High]: { text: 'Vysoké', bg: 'bg-red-600', textCol: 'text-red-100' },
    [RiskLevel.Critical]: { text: 'Kritické', bg: 'bg-purple-500', textCol: 'text-purple-100' },
};


const DetailItem: React.FC<{ label: string; value: string | number }> = ({ label, value }) => (
  <div className="flex justify-between text-sm py-2 border-b border-gray-700">
    <span className="text-gray-400">{label}</span>
    <span className="font-mono text-right truncate">{value}</span>
  </div>
);

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="mb-4">
        <h4 className="text-lg font-semibold text-cyan-400 mb-2">{title}</h4>
        <div className="bg-gray-900/50 rounded-md p-3 text-sm space-y-2">
            {children}
        </div>
    </div>
);

const ProcessDetailView: React.FC<{ process: Process | null }> = ({ process }) => {
  if (!process) {
    return <div className="p-4 text-gray-500 h-full flex items-center justify-center">
        <div className="text-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="mx-auto mb-2 text-gray-600"><path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/><path d="M22 10a3 3 0 0 0-3-3h-2.207a5.502 5.502 0 0 0-10.702.5"/></svg>
            <p>Vyberte proces pro zobrazení detailů</p>
        </div>
    </div>;
  }
  
  const riskInfo = riskDetailMap[process.riskLevel];

  return (
    <div className="p-4 h-full flex flex-col">
      <div className="border-b border-gray-700 pb-3 mb-4">
        <h3 className="text-xl font-bold text-white truncate">{process.name}</h3>
        <p className="text-xs text-gray-500 font-mono truncate">{process.path}</p>
      </div>

      <div className="flex-grow overflow-y-auto">
        <div className="mb-4">
            <div className="flex justify-between items-center text-sm py-2">
                <span className="text-gray-400">Úroveň Rizika</span>
                <span className={`px-3 py-1 text-xs font-bold rounded-full ${riskInfo.bg} ${riskInfo.textCol}`}>{riskInfo.text}</span>
            </div>
            <DetailItem label="Skóre Anomálie" value={process.anomalyScore} />
        </div>
        
        {process.isAnomaly && process.anomalyReason && (
             <Section title="Důvod Anomálie">
                <p className="text-red-400 text-xs leading-relaxed">{process.anomalyReason}</p>
            </Section>
        )}

        <Section title="Základní Informace">
            <DetailItem label="PID" value={process.pid} />
            <DetailItem label="Rodičovský PID" value={process.ppid} />
            <DetailItem label="Uživatel" value={process.user} />
        </Section>
        
        <Section title="Využití Zdrojů">
            <DetailItem label="CPU" value={`${process.cpu.toFixed(2)} %`} />
            <DetailItem label="Paměť" value={`${process.memory.toFixed(2)} MB`} />
        </Section>

        {process.networkConnections.length > 0 && (
          <Section title="Síťová Aktivita">
            {process.networkConnections.map((conn: NetworkConnection) => (
              <div key={conn.id} className="p-2 bg-gray-800 rounded">
                <p>Cíl: <span className="font-mono text-cyan-300">{conn.destinationIp}:{conn.port}</span></p>
                <p className="text-xs text-gray-400">Data: {conn.dataTransferred} KB</p>
              </div>
            ))}
          </Section>
        )}

        {process.fileActivity.length > 0 && (
          <Section title="Aktivita Souborů">
            {process.fileActivity.map((act: FileActivity) => (
              <div key={act.id} className="p-2 bg-gray-800 rounded">
                <p>Operace: <span className="font-semibold">{act.operation.toUpperCase()}</span></p>
                <p className="text-xs text-gray-400 truncate">{act.filePath}</p>
              </div>
            ))}
          </Section>
        )}
      </div>
    </div>
  );
};

export default ProcessDetailView;
