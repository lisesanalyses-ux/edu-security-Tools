
import React, { useState } from 'react';
import { Process, RiskLevel } from '../types';

interface ProcessNodeProps {
  process: Process;
  onSelectProcess: (process: Process) => void;
  selectedProcessId?: number | null;
  depth: number;
}

const riskColorMap: { [key in RiskLevel]: string } = {
  [RiskLevel.None]: 'border-gray-600 hover:bg-gray-700/50',
  [RiskLevel.Low]: 'border-yellow-600 hover:bg-yellow-600/20',
  [RiskLevel.Medium]: 'border-orange-500 hover:bg-orange-500/20',
  [RiskLevel.High]: 'border-red-600 hover:bg-red-600/20',
  [RiskLevel.Critical]: 'border-purple-500 hover:bg-purple-500/20 animate-pulse',
};

const riskTextColorMap: { [key in RiskLevel]: string } = {
  [RiskLevel.None]: 'text-gray-400',
  [RiskLevel.Low]: 'text-yellow-400',
  [RiskLevel.Medium]: 'text-orange-400',
  [RiskLevel.High]: 'text-red-400',
  [RiskLevel.Critical]: 'text-purple-400',
};


const ChevronRight: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="m9 18 6-6-6-6"/></svg>
);
const ChevronDown: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="m6 9 6 6 6-6"/></svg>
);


const ProcessNode: React.FC<ProcessNodeProps> = ({ process, onSelectProcess, selectedProcessId, depth }) => {
  const [isExpanded, setIsExpanded] = useState(depth < 2);
  const hasChildren = process.children && process.children.length > 0;

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsExpanded(!isExpanded);
  };

  const handleSelect = () => {
    onSelectProcess(process);
  };

  const isSelected = selectedProcessId === process.pid;

  return (
    <div>
      <div
        onClick={handleSelect}
        className={`flex items-center p-2 rounded-md cursor-pointer transition-all duration-150 border-l-4 ${riskColorMap[process.riskLevel]} ${isSelected ? 'bg-cyan-500/20' : ''}`}
        style={{ paddingLeft: `${depth * 20 + 8}px` }}
      >
        <div className="flex items-center flex-grow w-full">
            {hasChildren ? (
              <button onClick={handleToggle} className="mr-2 p-1 rounded-full hover:bg-gray-600 focus:outline-none">
                  {isExpanded ? <ChevronDown /> : <ChevronRight />}
              </button>
            ) : (
              <span className="w-8 mr-2"></span>
            )}

            <div className="flex justify-between items-center w-full">
                <div>
                    <span className="font-mono text-sm text-gray-400 mr-2">{process.pid}</span>
                    <span className="font-semibold text-white">{process.name}</span>
                </div>
                <div className={`text-xs font-bold px-2 py-1 rounded-full ${riskTextColorMap[process.riskLevel]}`}>
                    {process.anomalyScore > 0 ? `SKÓRE: ${process.anomalyScore}` : 'OK'}
                </div>
            </div>
        </div>
      </div>

      {hasChildren && isExpanded && (
        <div className="pl-5 border-l border-gray-700 ml-5">
          {process.children.map(child => (
            <ProcessNode
              key={child.pid}
              process={child}
              onSelectProcess={onSelectProcess}
              selectedProcessId={selectedProcessId}
              depth={depth + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default ProcessNode;
