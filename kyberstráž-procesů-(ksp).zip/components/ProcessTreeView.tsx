
import React, { useMemo } from 'react';
import { Process } from '../types';
import ProcessNode from './ProcessNode';

interface ProcessTreeViewProps {
  processes: Process[];
  onSelectProcess: (process: Process) => void;
  selectedProcessId?: number | null;
}

const buildTree = (processes: Process[]): Process[] => {
  const processMap = new Map<number, Process>();
  const tree: Process[] = [];

  processes.forEach(p => {
    processMap.set(p.pid, { ...p, children: [] });
  });

  processMap.forEach(p => {
    if (p.ppid && processMap.has(p.ppid)) {
      const parent = processMap.get(p.ppid);
      parent?.children.push(p);
    } else {
      tree.push(p);
    }
  });

  return tree;
};


const ProcessTreeView: React.FC<ProcessTreeViewProps> = ({ processes, onSelectProcess, selectedProcessId }) => {
  const processTree = useMemo(() => buildTree(processes), [processes]);

  return (
    <div className="space-y-1">
      {processTree.map(process => (
        <ProcessNode
          key={process.pid}
          process={process}
          onSelectProcess={onSelectProcess}
          selectedProcessId={selectedProcessId}
          depth={0}
        />
      ))}
    </div>
  );
};

export default ProcessTreeView;
