
import { Process, RiskLevel, NetworkConnection, FileActivity } from '../types';

let pidCounter = 1000;

const createProcess = (ppid: number, name: string, path: string, user: string, riskLevel: RiskLevel = RiskLevel.None, anomalyScore: number = 0): Process => {
  pidCounter += 4;
  return {
    pid: pidCounter,
    ppid,
    name,
    path,
    user,
    cpu: parseFloat((Math.random() * 2).toFixed(2)),
    memory: parseFloat((Math.random() * 100 + 10).toFixed(2)),
    riskLevel,
    anomalyScore,
    networkConnections: [],
    fileActivity: [],
    children: [],
  };
};

const baseProcesses: Process[] = [
  { pid: 1, ppid: 0, name: 'system', path: 'System', user: 'SYSTEM', cpu: 0.1, memory: 50, riskLevel: RiskLevel.None, anomalyScore: 0, networkConnections: [], fileActivity: [], children: [] },
  { pid: 4, ppid: 1, name: 'smss.exe', path: 'C:\\Windows\\System32\\smss.exe', user: 'SYSTEM', cpu: 0.0, memory: 1.2, riskLevel: RiskLevel.None, anomalyScore: 0, networkConnections: [], fileActivity: [], children: [] },
  { pid: 588, ppid: 580, name: 'csrss.exe', path: 'C:\\Windows\\System32\\csrss.exe', user: 'SYSTEM', cpu: 0.2, memory: 6.5, riskLevel: RiskLevel.None, anomalyScore: 0, networkConnections: [], fileActivity: [], children: [] },
  { pid: 668, ppid: 580, name: 'wininit.exe', path: 'C:\\Windows\\System32\\wininit.exe', user: 'SYSTEM', cpu: 0.0, memory: 4.8, riskLevel: RiskLevel.None, anomalyScore: 0, networkConnections: [], fileActivity: [], children: [] },
  { pid: 800, ppid: 792, name: 'services.exe', path: 'C:\\Windows\\System32\\services.exe', user: 'SYSTEM', cpu: 0.1, memory: 10.1, riskLevel: RiskLevel.None, anomalyScore: 0, networkConnections: [], fileActivity: [], children: [] },
  { pid: 812, ppid: 792, name: 'lsass.exe', path: 'C:\\Windows\\System32\\lsass.exe', user: 'SYSTEM', cpu: 0.3, memory: 25.3, riskLevel: RiskLevel.None, anomalyScore: 0, networkConnections: [], fileActivity: [], children: [] },
  { pid: 1100, ppid: 700, name: 'svchost.exe', path: 'C:\\Windows\\System32\\svchost.exe', user: 'SYSTEM', cpu: 0.5, memory: 55.0, riskLevel: RiskLevel.None, anomalyScore: 0, networkConnections: [], fileActivity: [], children: [] },
  { pid: 1220, ppid: 668, name: 'explorer.exe', path: 'C:\\Windows\\explorer.exe', user: 'JaneDoe', cpu: 2.1, memory: 150.7, riskLevel: RiskLevel.None, anomalyScore: 0, networkConnections: [], fileActivity: [], children: [] },
  { pid: 2100, ppid: 1220, name: 'chrome.exe', path: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', user: 'JaneDoe', cpu: 5.5, memory: 350.2, riskLevel: RiskLevel.None, anomalyScore: 0, networkConnections: [{id: 'n1', destinationIp: '172.217.16.142', port: 443, dataTransferred: 1204}], fileActivity: [], children: [] },
  { pid: 2200, ppid: 1220, name: 'WINWORD.EXE', path: 'C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE', user: 'JaneDoe', cpu: 1.2, memory: 180.5, riskLevel: RiskLevel.None, anomalyScore: 0, networkConnections: [], fileActivity: [], children: [] },
];

class ProcessService {
  private processes: Process[] = [];

  constructor() {
    this.processes = JSON.parse(JSON.stringify(baseProcesses)); // Deep copy
    pidCounter = Math.max(...this.processes.map(p => p.pid)) + 10;
  }
  
  getInitialProcesses(): Process[] {
    return JSON.parse(JSON.stringify(this.processes));
  }

  updateProcesses(currentProcesses: Process[]): Process[] {
    let updated = [...currentProcesses];

    // Simulate metric changes
    updated.forEach(p => {
      p.cpu = Math.max(0, parseFloat((p.cpu + (Math.random() - 0.5) * 0.5).toFixed(2)));
      p.memory = Math.max(1, parseFloat((p.memory + (Math.random() - 0.5) * 2).toFixed(2)));
    });

    // Randomly spawn a new legitimate process
    if (Math.random() < 0.05) {
      const parent = updated.find(p => p.name === 'explorer.exe') || updated[0];
      const newProc = createProcess(parent.pid, 'notepad.exe', 'C:\\Windows\\System32\\notepad.exe', 'JaneDoe');
      updated.push(newProc);
    }

    // Randomly spawn an anomaly
    if (Math.random() < 0.08) {
      this.introduceAnomaly(updated);
    }
    
    // Randomly terminate a process
    if (Math.random() < 0.03) {
       const nonCoreProcesses = updated.filter(p => p.ppid !== 0 && p.ppid !== 1 && p.name !== 'explorer.exe' );
       if (nonCoreProcesses.length > 5) {
           const toTerminate = nonCoreProcesses[Math.floor(Math.random() * nonCoreProcesses.length)];
           updated = updated.filter(p => p.pid !== toTerminate.pid && p.ppid !== toTerminate.pid);
       }
    }

    return updated;
  }
  
  private introduceAnomaly(processes: Process[]) {
    const anomalyType = Math.floor(Math.random() * 3);
    const wordProcess = processes.find(p => p.name === 'WINWORD.EXE');

    if (anomalyType === 0 && wordProcess && !processes.some(p => p.ppid === wordProcess.pid)) {
      // Word spawning PowerShell (High Risk)
      const anomaly = createProcess(wordProcess.pid, 'powershell.exe', 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe', 'JaneDoe', RiskLevel.High, 85);
      anomaly.isAnomaly = true;
      anomaly.anomalyReason = 'Legitimní proces (WINWORD.EXE) spustil potenciálně nebezpečný podřízený proces (powershell.exe). Malware to často využívá ke spuštění škodlivých skriptů bez detekce.';
      processes.push(anomaly);
    } else if (anomalyType === 1) {
      // Unusual network traffic (Medium Risk)
      const targetProc = processes.find(p => p.name === 'svchost.exe');
      if (targetProc && !targetProc.isAnomaly) {
        targetProc.riskLevel = RiskLevel.Medium;
        targetProc.anomalyScore = 65;
        targetProc.isAnomaly = true;
        targetProc.anomalyReason = 'Proces se připojuje k neobvyklé IP adrese v zahraničí. Může se jednat o komunikaci s C&C serverem (Command & Control).';
        targetProc.networkConnections.push({
          id: `nc-${Date.now()}`,
          destinationIp: '198.51.100.23',
          port: 8080,
          dataTransferred: parseFloat((Math.random() * 50).toFixed(2)),
        });
      }
    } else {
      // High CPU usage (Low Risk)
      const regularProc = processes.find(p => p.name === 'chrome.exe');
      if (regularProc && !regularProc.isAnomaly) {
        regularProc.riskLevel = RiskLevel.Low;
        regularProc.anomalyScore = 40;
        regularProc.cpu = parseFloat((Math.random() * 20 + 70).toFixed(2));
        regularProc.isAnomaly = true;
        regularProc.anomalyReason = 'Proces náhle spotřebovává extrémní množství CPU. Může to být známka crypto-miningu nebo jiné nežádoucí aktivity.';
      }
    }
  }
}

export const processService = new ProcessService();
