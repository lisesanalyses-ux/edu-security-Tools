
export enum RiskLevel {
  None = 'None',
  Low = 'Low',
  Medium = 'Medium',
  High = 'High',
  Critical = 'Critical',
}

export interface NetworkConnection {
  id: string;
  destinationIp: string;
  port: number;
  dataTransferred: number; // in KB
}

export interface FileActivity {
  id: string;
  filePath: string;
  operation: 'read' | 'write' | 'delete';
  timestamp: Date;
}

export interface Process {
  pid: number;
  ppid: number;
  name: string;
  path: string;
  user: string;
  cpu: number;
  memory: number; // in MB
  riskLevel: RiskLevel;
  anomalyScore: number;
  networkConnections: NetworkConnection[];
  fileActivity: FileActivity[];
  children: Process[];
  isAnomaly?: boolean;
  anomalyReason?: string;
  userAcknowledged?: boolean;
}

export interface Alert {
  process: Process;
  message: string;
  details: string;
}
