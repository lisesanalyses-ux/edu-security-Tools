
import React, { useState, useEffect, useCallback } from 'react';
import { Process } from './types';
import { getMockProcesses, buildProcessTree } from './services/mockDataService';
import ProcessTreeView from './components/ProcessTreeView';
import ThreatAnalysisView from './components/ThreatAnalysisView';
import { KspIcon } from './components/Icons';

const App: React.FC = () => {
  const [processes, setProcesses] = useState<Process[]>([]);
  const [selectedProcess, setSelectedProcess] = useState<Process | null>(null);

  useEffect(() => {
    const processData = getMockProcesses();
    const processTree = buildProcessTree(processData);
    setProcesses(processTree);
    // Select the first high-risk process by default for demonstration
    const highRiskProcess = processData.find(p => p.riskScore > 70);
    if (highRiskProcess) {
        setSelectedProcess(highRiskProcess);
    }
  }, []);

  const handleSelectProcess = useCallback((process: Process) => {
    setSelectedProcess(process);
  }, []);

  return (
    <div className="min-h-screen bg-ksp-bg text-ksp-text-primary font-sans flex flex-col">
      <header className="bg-ksp-surface/80 backdrop-blur-sm border-b border-ksp-panel sticky top-0 z-10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <KspIcon className="h-8 w-8 text-ksp-accent" />
            <h1 className="text-xl font-bold tracking-tight">
              Kyberstráž Procesů <span className="text-ksp-accent">(KSP)</span>
            </h1>
          </div>
          <div className="text-sm text-ksp-text-muted">Endpoint Monitoring Dashboard</div>
        </div>
      </header>
      <main className="flex-grow container mx-auto p-4 sm:p-6 lg:p-8 flex flex-col md:flex-row gap-6">
        <div className="w-full md:w-1/3 lg:w-1/4 flex-shrink-0">
          <div className="bg-ksp-surface rounded-lg shadow-lg h-full max-h-[calc(100vh-120px)] overflow-y-auto p-4">
            <h2 className="text-lg font-semibold mb-4 border-b border-ksp-panel pb-2">Strom Procesů</h2>
            <ProcessTreeView 
              processes={processes} 
              onSelectProcess={handleSelectProcess}
              selectedPid={selectedProcess?.pid ?? null}
            />
          </div>
        </div>
        <div className="w-full md:w-2/3 lg:w-3/4 flex-grow">
          <ThreatAnalysisView process={selectedProcess} />
        </div>
      </main>
    </div>
  );
};

export default App;
