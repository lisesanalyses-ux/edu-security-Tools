
import React, { useState } from 'react';
import { Process, RiskLevel } from '../types';
import { ChevronRightIcon, FileIcon } from './Icons';

interface ProcessTreeNodeProps {
  process: Process;
  onSelectProcess: (process: Process) => void;
  selectedPid: number | null;
  depth: number;
}

const getRiskColor = (level: RiskLevel): string => {
  switch (level) {
    case RiskLevel.Critical: return 'bg-risk-critical';
    case RiskLevel.High: return 'bg-risk-high';
    case RiskLevel.Medium: return 'bg-risk-medium';
    case RiskLevel.Low: return 'bg-risk-low';
    default: return 'bg-gray-500';
  }
};

const ProcessTreeNode: React.FC<ProcessTreeNodeProps> = ({ process, onSelectProcess, selectedPid, depth }) => {
  const [isExpanded, setIsExpanded] = useState(depth < 2 || process.riskScore > 50);
  const hasChildren = process.children && process.children.length > 0;
  const isSelected = process.pid === selectedPid;

  const handleToggleExpand = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (hasChildren) {
      setIsExpanded(!isExpanded);
    }
  };
  
  const handleSelect = () => {
    onSelectProcess(process);
  };

  return (
    <div>
      <div
        onClick={handleSelect}
        className={`flex items-center space-x-2 p-1.5 rounded-md cursor-pointer transition-colors duration-150 ${
          isSelected ? 'bg-ksp-accent/90 text-white' : 'hover:bg-ksp-panel'
        }`}
        style={{ paddingLeft: `${depth * 1.25}rem` }}
      >
        {hasChildren ? (
          <ChevronRightIcon
            onClick={handleToggleExpand}
            className={`h-4 w-4 flex-shrink-0 text-ksp-text-muted transition-transform duration-200 ${isExpanded ? 'rotate-90' : ''}`}
          />
        ) : (
          <div className="w-4 h-4 flex-shrink-0"></div>
        )}
        <div className="flex items-center space-x-2 flex-grow min-w-0">
          <FileIcon className="h-4 w-4 flex-shrink-0" />
          <span className="truncate text-sm font-medium">{process.name}</span>
          <span className="text-xs text-ksp-text-muted truncate">({process.pid})</span>
        </div>
        {process.riskScore > 0 && (
          <div
            className={`w-3 h-3 rounded-full flex-shrink-0 ${getRiskColor(process.riskLevel)}`}
            title={`Risk Score: ${process.riskScore}/100`}
          ></div>
        )}
      </div>
      {isExpanded && hasChildren && (
        <div className="space-y-1">
          {process.children.map(child => (
            <ProcessTreeNode
              key={child.pid}
              process={child}
              onSelectProcess={onSelectProcess}
              selectedPid={selectedPid}
              depth={depth + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default ProcessTreeNode;
