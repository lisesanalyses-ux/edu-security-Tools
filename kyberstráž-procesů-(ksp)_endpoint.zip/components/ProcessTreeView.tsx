
import React from 'react';
import { Process } from '../types';
import ProcessTreeNode from './ProcessTreeNode';

interface ProcessTreeViewProps {
  processes: Process[];
  onSelectProcess: (process: Process) => void;
  selectedPid: number | null;
}

const ProcessTreeView: React.FC<ProcessTreeViewProps> = ({ processes, onSelectProcess, selectedPid }) => {
  return (
    <div className="space-y-1">
      {processes.map(process => (
        <ProcessTreeNode 
          key={process.pid}
          process={process} 
          onSelectProcess={onSelectProcess}
          selectedPid={selectedPid}
          depth={0} 
        />
      ))}
    </div>
  );
};

export default ProcessTreeView;
