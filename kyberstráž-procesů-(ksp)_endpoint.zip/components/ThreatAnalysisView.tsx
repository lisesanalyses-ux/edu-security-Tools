
import React from 'react';
import { Process } from '../types';
import ProcessIdentification from './details/ProcessIdentification';
import RiskAnalysis from './details/RiskAnalysis';
import NetworkActivity from './details/NetworkActivity';
import FileSystemActivity from './details/FileSystemActivity';
import UserActions from './details/UserActions';
import { KspIcon } from './Icons';

interface ThreatAnalysisViewProps {
  process: Process | null;
}

const ThreatAnalysisView: React.FC<ThreatAnalysisViewProps> = ({ process }) => {
  if (!process) {
    return (
      <div className="flex items-center justify-center h-full bg-ksp-surface rounded-lg shadow-lg">
        <div className="text-center p-8">
          <KspIcon className="mx-auto h-16 w-16 text-ksp-panel" />
          <h3 className="mt-4 text-lg font-semibold text-ksp-text-secondary">Vyberte proces k analýze</h3>
          <p className="mt-1 text-sm text-ksp-text-muted">Zobrazí se podrobné informace o vybraném procesu.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-ksp-surface rounded-lg shadow-lg h-full max-h-[calc(100vh-120px)] overflow-y-auto p-4 sm:p-6 space-y-6">
      <ProcessIdentification process={process} />
      <RiskAnalysis process={process} />
      <NetworkActivity connections={process.networkConnections} />
      <FileSystemActivity operations={process.fileOperations} />
      <UserActions />
    </div>
  );
};

export default ThreatAnalysisView;
