
import React from 'react';
import { FileOperation } from '../../types';
import { FolderIcon } from '../Icons';

interface FileSystemActivityProps {
  operations: FileOperation[];
}

const FileSystemActivity: React.FC<FileSystemActivityProps> = ({ operations }) => {
  if (operations.length === 0) {
    return null;
  }

  return (
    <div>
      <h3 className="text-base font-semibold text-ksp-text-secondary mb-2 flex items-center"><FolderIcon className="h-5 w-5 mr-2" />Aktivita v Souborovém Systému</h3>
       <div className="bg-ksp-panel/50 rounded-lg overflow-hidden">
        <ul className="divide-y divide-ksp-panel">
            {operations.map(op => (
              <li key={op.id} className="p-3 flex items-center justify-between text-sm">
                <div className="flex items-center space-x-3">
                  <span className={`font-mono text-xs px-2 py-0.5 rounded ${op.type === 'Zápis' ? 'bg-blue-500/20 text-blue-300' : 'bg-gray-600'}`}>{op.type}</span>
                  <p className="font-mono text-ksp-text-secondary break-all">{op.path}</p>
                </div>
                {op.sensitive && <span className="ml-4 flex-shrink-0 text-xs font-bold text-yellow-400 bg-yellow-500/20 px-2 py-1 rounded-full">CITLIVÉ MÍSTO</span>}
              </li>
            ))}
        </ul>
       </div>
    </div>
  );
};

export default FileSystemActivity;
