
import React from 'react';
import { NetworkConnection } from '../../types';
import { GlobeIcon } from '../Icons';

interface NetworkActivityProps {
  connections: NetworkConnection[];
}

const NetworkActivity: React.FC<NetworkActivityProps> = ({ connections }) => {
  if (connections.length === 0) {
    return null;
  }
    
  const getReputationColor = (reputation: string) => {
    if (reputation === 'Uzel botnetu' || reputation === 'Podezřelá') return 'text-red-400';
    return 'text-green-400';
  }

  return (
    <div>
      <h3 className="text-base font-semibold text-ksp-text-secondary mb-2 flex items-center"><GlobeIcon className="h-5 w-5 mr-2" />Síťová Aktivita a C&C Analýza</h3>
      <div className="bg-ksp-panel/50 rounded-lg overflow-x-auto">
        <table className="min-w-full text-sm text-left">
          <thead className="bg-ksp-panel/50 text-xs text-ksp-text-muted uppercase tracking-wider">
            <tr>
              <th scope="col" className="px-4 py-2 font-medium">Cílová IP Adresa</th>
              <th scope="col" className="px-4 py-2 font-medium">Port</th>
              <th scope="col" className="px-4 py-2 font-medium">Geolokace</th>
              <th scope="col" className="px-4 py-2 font-medium">Reputace IP</th>
              <th scope="col" className="px-4 py-2 font-medium text-right">Data (Odes./Přij.)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ksp-panel">
            {connections.map(conn => (
              <tr key={conn.id}>
                <td className="px-4 py-2 font-mono">{conn.destinationIp}</td>
                <td className="px-4 py-2">{conn.port}</td>
                <td className="px-4 py-2">{conn.geolocation}</td>
                <td className={`px-4 py-2 font-semibold ${getReputationColor(conn.reputation)}`}>{conn.reputation}</td>
                <td className="px-4 py-2 text-right font-mono">{conn.dataSent} / {conn.dataReceived}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default NetworkActivity;
