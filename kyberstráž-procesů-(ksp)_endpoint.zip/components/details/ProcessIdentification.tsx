
import React from 'react';
import { Process } from '../../types';
import { KspIcon } from '../Icons';

interface ProcessIdentificationProps {
  process: Process;
}

const DetailItem: React.FC<{ label: string; value?: string | number; children?: React.ReactNode; className?: string }> = ({ label, value, children, className }) => (
  <div className={`break-words ${className}`}>
    <p className="text-xs font-medium text-ksp-text-muted">{label}</p>
    {value !== undefined && <p className="text-sm text-ksp-text-secondary">{value}</p>}
    {children}
  </div>
);

const ProcessIdentification: React.FC<ProcessIdentificationProps> = ({ process }) => {
  const getSignatureColor = (status: 'Ověřený' | 'Neověřený' | 'Chybí') => {
    if (status === 'Ověřený') return 'text-green-400';
    if (status === 'Neověřený') return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="bg-ksp-panel/50 rounded-lg p-4">
      <div className="flex items-start mb-4">
        <KspIcon className="h-8 w-8 text-ksp-accent mr-4 mt-1" />
        <div>
            <h3 className="text-lg font-bold text-ksp-text-primary">{process.name}</h3>
            <p className="text-sm text-ksp-text-muted break-all">{process.path}</p>
        </div>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        <DetailItem label="PID" value={process.pid} />
        <DetailItem label="PPID" value={process.ppid ?? 'N/A'} />
        <DetailItem label="Uživatel" value={process.user} />
        <DetailItem label="Úroveň integrity" value={process.integrity} />
        <DetailItem label="Čas spuštění" value={process.startTime} />
        <DetailItem label="Digitální Podpis">
          <p className={`text-sm font-semibold ${getSignatureColor(process.signature.status)}`}>
            {process.signature.status}
          </p>
          {process.signature.publisher && <p className="text-xs text-ksp-text-muted">{process.signature.publisher}</p>}
        </DetailItem>
        <DetailItem label="Hash souboru (SHA-256)" value={process.hash} className="col-span-2 sm:col-span-3 lg:col-span-2" />
      </div>
    </div>
  );
};

export default ProcessIdentification;
