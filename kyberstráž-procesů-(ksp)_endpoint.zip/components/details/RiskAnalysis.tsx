
import React from 'react';
import { Process, RiskLevel } from '../../types';
import { ShieldIcon } from '../Icons';

interface RiskAnalysisProps {
  process: Process;
}

const getRiskColorClasses = (level: RiskLevel): { text: string; bg: string, border: string } => {
  switch (level) {
    case RiskLevel.Critical: return { text: 'text-risk-critical', bg: 'bg-risk-critical/10', border: 'border-risk-critical' };
    case RiskLevel.High: return { text: 'text-risk-high', bg: 'bg-risk-high/10', border: 'border-risk-high' };
    case RiskLevel.Medium: return { text: 'text-risk-medium', bg: 'bg-risk-medium/10', border: 'border-risk-medium' };
    case RiskLevel.Low: return { text: 'text-risk-low', bg: 'bg-risk-low/10', border: 'border-risk-low' };
    default: return { text: 'text-gray-400', bg: 'bg-gray-400/10', border: 'border-gray-400' };
  }
};

const RiskAnalysis: React.FC<RiskAnalysisProps> = ({ process }) => {
  const riskColor = getRiskColorClasses(process.riskLevel);
  const riskPercentage = process.riskScore;

  return (
    <div>
      <h3 className="text-base font-semibold text-ksp-text-secondary mb-2 flex items-center"><ShieldIcon className="h-5 w-5 mr-2" />Skóre Rizika a Behaviorální Analýza</h3>
      <div className="bg-ksp-panel/50 rounded-lg p-4 grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Risk Score */}
        <div className="flex flex-col items-center justify-center text-center">
            <div className="relative h-28 w-28">
                <svg className="h-full w-full" viewBox="0 0 36 36">
                    <path
                        className="text-ksp-panel"
                        d="M18 2.0845
                        a 15.9155 15.9155 0 0 1 0 31.831
                        a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                    />
                    <path
                        className={riskColor.text}
                        strokeDasharray={`${riskPercentage}, 100`}
                        d="M18 2.0845
                        a 15.9155 15.9155 0 0 1 0 31.831
                        a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                        strokeLinecap="round"
                    />
                </svg>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                    <span className={`text-3xl font-bold ${riskColor.text}`}>{process.riskScore}</span>
                    <span className="text-xs text-ksp-text-muted">/100</span>
                </div>
            </div>
            <p className={`mt-2 text-lg font-bold ${riskColor.text}`}>{process.riskLevel} Riziko</p>
        </div>
        
        {/* Anomaly Categories */}
        <div className="md:col-span-2">
          <h4 className="font-semibold text-ksp-text-secondary mb-2">Kategorie Anomálie (Hlavní faktory)</h4>
          {process.anomalyReasons.length > 0 ? (
            <ul className="space-y-2">
              {process.anomalyReasons.map((item, index) => (
                <li key={index} className="flex items-center text-sm">
                  <span className={`mr-2 font-bold ${item.weight === 'Vysoká' ? 'text-red-400' : 'text-yellow-400'}`}>
                    {index + 1}.
                  </span>
                  <span>{item.reason}</span>
                  <span className={`ml-auto text-xs font-mono px-2 py-0.5 rounded ${item.weight === 'Vysoká' ? 'bg-red-500/20 text-red-300' : 'bg-yellow-500/20 text-yellow-300'}`}>{item.weight} váha</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-ksp-text-muted italic">Nebyly zjištěny žádné významné anomálie.</p>
          )}

          <div className="mt-4 pt-4 border-t border-ksp-panel">
            <h4 className="font-semibold text-ksp-text-secondary mb-2">Detekce Signatur (Blacklist)</h4>
            <p className="text-sm text-ksp-text-secondary">{process.signatureCheckResult}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RiskAnalysis;
