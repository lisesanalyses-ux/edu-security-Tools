
import React from 'react';

const UserActions: React.FC = () => {
  const handleAction = (action: string) => {
    alert(`Akce byla provedena: ${action}`);
  };

  return (
    <div>
      <h3 className="text-base font-semibold text-ksp-text-secondary mb-3">Interaktivní Akce a Učení (Zpětná Vazba)</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <button
          onClick={() => handleAction('Izolovat a Ukončit (Útok!)')}
          className="w-full text-left p-3 rounded-lg bg-red-600 hover:bg-red-700 transition-colors duration-200 text-white shadow-lg"
        >
          <p className="font-bold">🛑 Izolovat a Ukončit</p>
          <p className="text-xs text-red-100">Okamžitá náprava a zpřísnění pravidel.</p>
        </button>
        <button
          onClick={() => handleAction('Povolit a Naučit (Dobrý)')}
          className="w-full text-left p-3 rounded-lg bg-green-600 hover:bg-green-700 transition-colors duration-200 text-white shadow-lg"
        >
          <p className="font-bold">✅ Povolit a Naučit</p>
          <p className="text-xs text-green-100">Snížení falešných poplachů do budoucna.</p>
        </button>
        <button
          onClick={() => handleAction('Povolit jednou (Dočasné)')}
          className="w-full text-left p-3 rounded-lg bg-yellow-500 hover:bg-yellow-600 transition-colors duration-200 text-white shadow-lg"
        >
          <p className="font-bold">⏸️ Povolit jednou</p>
          <p className="text-xs text-yellow-100">Pouze pro aktuální spuštění.</p>
        </button>
        <button
          onClick={() => handleAction('Detailní Forenzní Sběr')}
          className="w-full text-left p-3 rounded-lg bg-ksp-panel hover:bg-gray-600 transition-colors duration-200 text-ksp-text-primary shadow-lg"
        >
          <p className="font-bold">🔬 Forenzní Sběr</p>
          <p className="text-xs text-ksp-text-muted">Uložit data pro hlubší analýzu.</p>
        </button>
      </div>
    </div>
  );
};

export default UserActions;
