
import { Process, RiskLevel } from '../types';

const mockProcesses: Omit<Process, 'children'>[] = [
  {
    pid: 1, ppid: null, name: 'system', path: 'kernel', user: 'SYSTEM', integrity: 'Vysoká', cpuUsage: 0.1, memoryUsage: '4 MB', runTime: '12d 4h',
    hash: 'N/A', signature: { status: 'Ověřený', publisher: 'NT KERNEL' }, startTime: '2023-10-15 08:00:00',
    riskScore: 0, riskLevel: RiskLevel.None, anomalyReasons: [], signatureCheckResult: 'N/A', networkConnections: [], fileOperations: []
  },
  {
    pid: 101, ppid: 1, name: 'smss.exe', path: 'C:\\Windows\\System32\\smss.exe', user: 'SYSTEM', integrity: 'Vysoká', cpuUsage: 0, memoryUsage: '1.2 MB', runTime: '12d 4h',
    hash: 'a1b2c3d4e5f6...', signature: { status: 'Ověřený', publisher: 'Microsoft Corporation' }, startTime: '2023-10-15 08:00:01',
    riskScore: 0, riskLevel: RiskLevel.None, anomalyReasons: [], signatureCheckResult: 'Čistý', networkConnections: [], fileOperations: []
  },
  {
    pid: 202, ppid: 101, name: 'wininit.exe', path: 'C:\\Windows\\System32\\wininit.exe', user: 'SYSTEM', integrity: 'Vysoká', cpuUsage: 0, memoryUsage: '5.5 MB', runTime: '12d 4h',
    hash: 'b2c3d4e5f6a1...', signature: { status: 'Ověřený', publisher: 'Microsoft Corporation' }, startTime: '2023-10-15 08:00:05',
    riskScore: 0, riskLevel: RiskLevel.None, anomalyReasons: [], signatureCheckResult: 'Čistý', networkConnections: [], fileOperations: []
  },
  {
    pid: 303, ppid: 202, name: 'services.exe', path: 'C:\\Windows\\System32\\services.exe', user: 'SYSTEM', integrity: 'Vysoká', cpuUsage: 0.2, memoryUsage: '12.1 MB', runTime: '12d 4h',
    hash: 'c3d4e5f6a1b2...', signature: { status: 'Ověřený', publisher: 'Microsoft Corporation' }, startTime: '2023-10-15 08:00:10',
    riskScore: 0, riskLevel: RiskLevel.None, anomalyReasons: [], signatureCheckResult: 'Čistý', networkConnections: [], fileOperations: []
  },
  {
    pid: 404, ppid: 303, name: 'svchost.exe', path: 'C:\\Windows\\System32\\svchost.exe', user: 'SYSTEM', integrity: 'Vysoká', cpuUsage: 1.5, memoryUsage: '88.7 MB', runTime: '12d 4h',
    hash: 'd4e5f6a1b2c3...', signature: { status: 'Ověřený', publisher: 'Microsoft Corporation' }, startTime: '2023-10-15 08:00:15',
    riskScore: 0, riskLevel: RiskLevel.None, anomalyReasons: [], signatureCheckResult: 'Čistý', networkConnections: [], fileOperations: []
  },
  {
    pid: 505, ppid: 404, name: 'explorer.exe', path: 'C:\\Windows\\explorer.exe', user: 'John.Doe', integrity: 'Střední', cpuUsage: 2.3, memoryUsage: '150.3 MB', runTime: '1d 2h',
    hash: 'e5f6a1b2c3d4...', signature: { status: 'Ověřený', publisher: 'Microsoft Corporation' }, startTime: '2023-10-26 10:00:00',
    riskScore: 0, riskLevel: RiskLevel.None, anomalyReasons: [], signatureCheckResult: 'Čistý', networkConnections: [], fileOperations: []
  },
  {
    pid: 606, ppid: 505, name: 'chrome.exe', path: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', user: 'John.Doe', integrity: 'Střední', cpuUsage: 5.1, memoryUsage: '450.2 MB', runTime: '0d 5h',
    hash: 'f6a1b2c3d4e5...', signature: { status: 'Ověřený', publisher: 'Google LLC' }, startTime: '2023-10-27 09:00:00',
    riskScore: 5, riskLevel: RiskLevel.Low, anomalyReasons: [], signatureCheckResult: 'Čistý', networkConnections: [
      { id: 'net1', destinationIp: '172.217.16.142', port: 443, geolocation: 'USA', reputation: 'Čistá', dataSent: '1.2 MB', dataReceived: '15.6 MB'}
    ], fileOperations: []
  },
  {
    pid: 707, ppid: 505, name: 'WINWORD.EXE', path: 'C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE', user: 'John.Doe', integrity: 'Střední', cpuUsage: 1.8, memoryUsage: '210.8 MB', runTime: '0d 1h',
    hash: 'a1b2c3d4e5f6...', signature: { status: 'Ověřený', publisher: 'Microsoft Corporation' }, startTime: '2023-10-27 13:00:00',
    riskScore: 0, riskLevel: RiskLevel.None, anomalyReasons: [], signatureCheckResult: 'Čistý', networkConnections: [], fileOperations: []
  },
  {
    pid: 808, ppid: 707, name: 'powershell.exe', path: 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe', user: 'John.Doe', integrity: 'Vysoká', cpuUsage: 25.0, memoryUsage: '120.5 MB', runTime: '0d 0h 5m',
    hash: 'b8c9d0e1f2a3...', signature: { status: 'Ověřený', publisher: 'Microsoft Corporation' }, startTime: '2023-10-27 13:05:00',
    riskScore: 85, riskLevel: RiskLevel.Critical, 
    anomalyReasons: [
      { reason: 'Neobvyklý rodičovský proces (WINWORD.EXE)', weight: 'Vysoká' },
      { reason: 'Neznámá síťová komunikace', weight: 'Vysoká' },
      { reason: 'Přístup k citlivým souborům v adresáři Dokumenty', weight: 'Střední' }
    ],
    signatureCheckResult: 'Čistý (bezpečný soubor, ale podezřelé chování)',
    networkConnections: [
      { id: 'net2', destinationIp: '185.234.12.55', port: 8443, geolocation: 'Rusko', reputation: 'Uzel botnetu', dataSent: '5.3 MB', dataReceived: '10.1 KB'}
    ],
    fileOperations: [
      { id: 'file1', type: 'Čtení', path: 'C:\\Users\\John.Doe\\Documents\\hesla.docx', sensitive: true },
      { id: 'file2', type: 'Čtení', path: 'C:\\Users\\John.Doe\\Documents\\*.pdf', sensitive: true },
      { id: 'file3', type: 'Zápis', path: 'C:\\Users\\John.Doe\\AppData\\Local\\Temp\\data.bin', sensitive: false },
    ]
  },
  {
    pid: 909, ppid: 505, name: 'svchost.exe', path: 'C:\\Users\\John.Doe\\AppData\\Local\\Temp\\svchost.exe', user: 'John.Doe', integrity: 'Střední', cpuUsage: 95.0, memoryUsage: '50.0 MB', runTime: '0d 2h 15m',
    hash: 'c9d0e1f2a3b8...', signature: { status: 'Chybí' }, startTime: '2023-10-27 11:00:00',
    riskScore: 72, riskLevel: RiskLevel.High,
    anomalyReasons: [
      { reason: 'Vysoké využití CPU (těžba kryptoměn)', weight: 'Vysoká' },
      { reason: 'Spuštění z neobvyklého adresáře (Temp)', weight: 'Vysoká' },
      { reason: 'Chybějící digitální podpis', weight: 'Střední' },
    ],
    signatureCheckResult: 'Nalezeno v databázi hrozeb jako "XMRig Miner"',
    networkConnections: [
       { id: 'net3', destinationIp: '45.12.5.100', port: 14444, geolocation: 'Čína', reputation: 'Podezřelá', dataSent: '10.5 MB', dataReceived: '25.3 KB'}
    ],
    fileOperations: [
       { id: 'file4', type: 'Zápis', path: 'C:\\Users\\John.Doe\\AppData\\Local\\Temp\\config.json', sensitive: false }
    ],
  },
];

export const getMockProcesses = (): Omit<Process, 'children'>[] => {
  return mockProcesses;
};

export const buildProcessTree = (processes: Omit<Process, 'children'>[]): Process[] => {
  const processMap = new Map<number, Process>();
  const rootProcesses: Process[] = [];

  processes.forEach(p => {
    processMap.set(p.pid, { ...p, children: [] });
  });

  processMap.forEach(p => {
    if (p.ppid && processMap.has(p.ppid)) {
      processMap.get(p.ppid)!.children.push(p);
    } else {
      rootProcesses.push(p);
    }
  });

  return rootProcesses;
};
