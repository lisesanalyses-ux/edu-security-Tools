
export enum RiskLevel {
  None = 'Žádné',
  Low = 'Nízké',
  Medium = 'Střední',
  High = 'Vysoké',
  Critical = 'Kritické',
}

export interface NetworkConnection {
  id: string;
  destinationIp: string;
  port: number;
  geolocation: string;
  reputation: 'Čistá' | 'Podezřelá' | 'Uzel botnetu';
  dataSent: string;
  dataReceived: string;
}

export interface FileOperation {
  id: string;
  type: 'Čtení' | 'Zápis' | 'Smazání';
  path: string;
  sensitive: boolean;
}

export interface Process {
  pid: number;
  ppid: number | null;
  name: string;
  path: string;
  user: string;
  integrity: 'Vysoká' | 'Střední' | 'Nízká';
  cpuUsage: number;
  memoryUsage: string;
  runTime: string;
  hash: string;
  signature: {
    status: 'Ověřený' | 'Neověřený' | 'Chybí';
    publisher?: string;
  };
  startTime: string;
  riskScore: number; // 0-100
  riskLevel: RiskLevel;
  anomalyReasons: { reason: string; weight: 'Vysoká' | 'Střední' | 'Nízká' }[];
  signatureCheckResult: string;
  networkConnections: NetworkConnection[];
  fileOperations: FileOperation[];
  children: Process[];
}
