
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { SecurityFinding, FindingStatus, RiskCategory } from './types';
import { MOCK_FINDINGS, ICONS } from './constants';
import Dashboard from './components/Dashboard';
import RiskDetailModal from './components/RiskDetailModal';
import { getEnhancedExplanation } from './services/geminiService';

const App: React.FC = () => {
  const [findings, setFindings] = useState<SecurityFinding[]>([]);
  const [selectedFinding, setSelectedFinding] = useState<SecurityFinding | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [aiExplanation, setAiExplanation] = useState<string>('');
  const [isLoadingAI, setIsLoadingAI] = useState<boolean>(false);

  useEffect(() => {
    // Simulate fetching data from a scan
    setFindings(MOCK_FINDINGS);
  }, []);

  const score = useMemo(() => {
    if (findings.length === 0) return 100;
    const fixedCount = findings.filter(f => f.status === FindingStatus.FIXED).length;
    return Math.round((fixedCount / findings.length) * 100);
  }, [findings]);

  const handleSelectFinding = useCallback((finding: SecurityFinding) => {
    setSelectedFinding(finding);
    setIsModalOpen(true);
    setAiExplanation(''); // Clear previous explanation
  }, []);

  const handleCloseModal = useCallback(() => {
    setIsModalOpen(false);
    setSelectedFinding(null);
  }, []);

  const handleFixFinding = useCallback((findingId: string) => {
    // In a real app, this would trigger a PowerShell script. Here, we simulate the fix.
    setFindings(prevFindings =>
      prevFindings.map(f =>
        f.id === findingId ? { ...f, status: FindingStatus.FIXED } : f
      )
    );
    // Also update the selected finding if it's the one being fixed
    setSelectedFinding(prev => prev && prev.id === findingId ? {...prev, status: FindingStatus.FIXED} : prev);
  }, []);

  const handleAskAI = useCallback(async () => {
    if (!selectedFinding) return;
    setIsLoadingAI(true);
    setAiExplanation('');
    try {
        const explanation = await getEnhancedExplanation(selectedFinding.title);
        setAiExplanation(explanation);
    } catch (error) {
        console.error(error);
        setAiExplanation("Failed to load explanation.");
    } finally {
        setIsLoadingAI(false);
    }
  }, [selectedFinding]);

  const findingsByCategory = useMemo(() => {
      const grouped: { [key in RiskCategory]?: SecurityFinding[] } = {};
      for (const finding of findings) {
          if (!grouped[finding.category]) {
              grouped[finding.category] = [];
          }
          grouped[finding.category]!.push(finding);
      }
      return grouped;
  }, [findings]);


  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans p-4 sm:p-6 lg:p-8">
      <header className="mb-8">
        <div className="flex items-center space-x-3">
          <ICONS.shieldCheck className="w-10 h-10 text-cyan-400" />
          <div>
            <h1 className="text-3xl font-bold text-white">Windows Security Auditor</h1>
            <p className="text-gray-400">Your system's security posture at a glance.</p>
          </div>
        </div>
      </header>

      <main>
        <Dashboard
          score={score}
          findingsByCategory={findingsByCategory}
          onSelectFinding={handleSelectFinding}
          totalFindings={findings.length}
          fixedFindings={findings.filter(f => f.status === FindingStatus.FIXED).length}
        />
      </main>

      {isModalOpen && selectedFinding && (
        <RiskDetailModal
          finding={selectedFinding}
          onClose={handleCloseModal}
          onFix={handleFixFinding}
          onAskAI={handleAskAI}
          aiExplanation={aiExplanation}
          isLoadingAI={isLoadingAI}
        />
      )}
    </div>
  );
};

export default App;
