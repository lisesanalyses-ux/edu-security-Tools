
import React from 'react';
import { SecurityFinding, FindingStatus, RiskCategory } from '../types';
import { ICONS } from '../constants';
import ScoreIndicator from './ScoreIndicator';
import RiskCategoryChart from './RiskCategoryChart';

interface DashboardProps {
  score: number;
  findingsByCategory: { [key in RiskCategory]?: SecurityFinding[] };
  onSelectFinding: (finding: SecurityFinding) => void;
  totalFindings: number;
  fixedFindings: number;
}

const severityColorMap = {
  Critical: 'bg-red-500/20 text-red-400 border border-red-500/30',
  High: 'bg-orange-500/20 text-orange-400 border border-orange-500/30',
  Medium: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30',
  Low: 'bg-blue-500/20 text-blue-400 border border-blue-500/30',
};

const FindingRow: React.FC<{finding: SecurityFinding, onSelect: (finding: SecurityFinding) => void}> = ({ finding, onSelect }) => (
    <li
        onClick={() => onSelect(finding)}
        className="flex items-center justify-between p-3 hover:bg-gray-700/50 rounded-lg cursor-pointer transition-colors duration-200"
    >
        <div className="flex items-center space-x-3">
            {finding.status === FindingStatus.RISK ? (
                <ICONS.shieldExclamation className="w-6 h-6 text-red-500 flex-shrink-0" />
            ) : (
                <ICONS.shieldCheck className="w-6 h-6 text-green-500 flex-shrink-0" />
            )}
            <div>
                <p className="font-medium text-gray-200">{finding.title}</p>
                <span className={`text-xs px-2 py-0.5 rounded-full ${severityColorMap[finding.severity]}`}>{finding.severity}</span>
            </div>
        </div>
        <ICONS.arrowRight className="w-5 h-5 text-gray-500" />
    </li>
);

const Dashboard: React.FC<DashboardProps> = ({ score, findingsByCategory, onSelectFinding, totalFindings, fixedFindings }) => {
  const sortedCategories = Object.keys(findingsByCategory).sort() as RiskCategory[];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-1 space-y-8">
        <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700/50">
            <h2 className="text-xl font-bold mb-4 text-white">Overall Security Score</h2>
            <ScoreIndicator score={score} />
            <p className="text-center text-gray-400 mt-4">{fixedFindings} of {totalFindings} checks passed.</p>
        </div>
        <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700/50">
            <h2 className="text-xl font-bold mb-4 text-white">Risk Distribution</h2>
            <RiskCategoryChart findingsByCategory={findingsByCategory} />
        </div>
      </div>

      <div className="lg:col-span-2 bg-gray-800/50 rounded-xl p-6 border border-gray-700/50">
        <h2 className="text-xl font-bold mb-4 text-white">Security Checks</h2>
        <div className="space-y-6">
            {sortedCategories.length > 0 ? (
                sortedCategories.map(category => {
                    const findings = findingsByCategory[category]!;
                    const openRisks = findings.filter(f => f.status === FindingStatus.RISK).length;
                    return (
                        <div key={category}>
                            <div className="flex justify-between items-baseline mb-2">
                                <h3 className="font-semibold text-lg text-cyan-400">{category}</h3>
                                {openRisks > 0 && 
                                    <span className="text-sm bg-red-500/20 text-red-300 px-2 py-1 rounded-md">{openRisks} open risk{openRisks > 1 ? 's' : ''}</span>
                                }
                            </div>
                            <ul className="divide-y divide-gray-700/50">
                                {findings.map(finding => (
                                    <FindingRow key={finding.id} finding={finding} onSelect={onSelectFinding} />
                                ))}
                            </ul>
                        </div>
                    );
                })
            ) : (
                <p className="text-gray-400">No security findings available.</p>
            )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
