
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { SecurityFinding, FindingStatus, RiskCategory } from '../types';

interface RiskCategoryChartProps {
    findingsByCategory: { [key in RiskCategory]?: SecurityFinding[] };
}

const RiskCategoryChart: React.FC<RiskCategoryChartProps> = ({ findingsByCategory }) => {
    const data = Object.entries(findingsByCategory).map(([category, findings]) => ({
        name: category.split(' ')[0], // Shorten name for chart
        // Fix: Handle potentially undefined 'findings' by defaulting to an empty array.
        risks: (findings || []).filter(f => f.status === FindingStatus.RISK).length,
    })).filter(d => d.risks > 0);

    const colors = ['#f87171', '#fb923c', '#facc15', '#60a5fa'];

    if (data.length === 0) {
        return <div className="text-center text-gray-400 p-4">No open risks to display.</div>
    }

    return (
        <div style={{ width: '100%', height: 200 }}>
            <ResponsiveContainer>
                <BarChart data={data} layout="vertical" margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                    <XAxis type="number" stroke="#9ca3af" tick={{ fill: '#9ca3af', fontSize: 12 }} allowDecimals={false} />
                    <YAxis type="category" dataKey="name" stroke="#9ca3af" tick={{ fill: '#9ca3af', fontSize: 12 }} width={70} />
                    <Tooltip
                        cursor={{ fill: 'rgba(255, 255, 255, 0.1)' }}
                        contentStyle={{
                            background: '#1f2937',
                            border: '1px solid #4b5563',
                            borderRadius: '0.5rem',
                        }}
                        labelStyle={{ color: '#e5e7eb' }}
                    />
                    <Bar dataKey="risks" barSize={20}>
                        {data.map((entry, index) => (
                           <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                        ))}
                    </Bar>
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
};

export default RiskCategoryChart;