
import React from 'react';
import { SecurityFinding, FindingStatus } from '../types';
import { ICONS } from '../constants';

interface RiskDetailModalProps {
  finding: SecurityFinding;
  onClose: () => void;
  onFix: (findingId: string) => void;
  onAskAI: () => void;
  aiExplanation: string;
  isLoadingAI: boolean;
}

const RiskDetailModal: React.FC<RiskDetailModalProps> = ({
  finding,
  onClose,
  onFix,
  onAskAI,
  aiExplanation,
  isLoadingAI
}) => {
  const isFixed = finding.status === FindingStatus.FIXED;

  return (
    <div
      className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="bg-gray-800 rounded-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto flex flex-col border border-gray-700 shadow-2xl animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="flex items-center justify-between p-4 border-b border-gray-700 sticky top-0 bg-gray-800 z-10">
          <div className="flex items-center space-x-3">
            {isFixed ? (
              <ICONS.shieldCheck className="w-8 h-8 text-green-400" />
            ) : (
              <ICONS.shieldExclamation className="w-8 h-8 text-red-400" />
            )}
            <h2 className="text-xl font-bold text-white">{finding.title}</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <ICONS.xMark className="w-6 h-6" />
          </button>
        </header>

        <div className="p-6 space-y-6">
          {/* Status Badge */}
          <div className="flex items-center justify-between">
            <span className={`px-3 py-1 text-sm font-semibold rounded-full ${
                isFixed ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'
            }`}>
              Status: {isFixed ? 'Fixed' : 'At Risk'}
            </span>
            <span className={`px-3 py-1 text-sm font-semibold rounded-full ${
                finding.severity === 'Critical' ? 'bg-red-500/20 text-red-300' :
                finding.severity === 'High' ? 'bg-orange-500/20 text-orange-300' :
                finding.severity === 'Medium' ? 'bg-yellow-500/20 text-yellow-300' : 'bg-blue-500/20 text-blue-300'
            }`}>
              Severity: {finding.severity}
            </span>
          </div>

          {/* Architecture */}
          <div>
            <h3 className="font-semibold text-lg text-cyan-400 mb-2">What's Happening? (The Architecture)</h3>
            <p className="text-gray-300 leading-relaxed">{finding.architecture}</p>
            <a href={finding.reference.url} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-400 hover:underline mt-2 inline-block">
              Reference: {finding.reference.name} &rarr;
            </a>
          </div>

          {/* AI Explanation */}
           <div>
              <h3 className="font-semibold text-lg text-cyan-400 mb-2 flex items-center space-x-2">
                <ICONS.sparkles className="w-5 h-5" />
                <span>Gemini AI Explanation</span>
              </h3>
              {!aiExplanation && !isLoadingAI && (
                 <button onClick={onAskAI} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300">
                    Explain this risk
                 </button>
              )}
              {isLoadingAI && <div className="text-gray-400">Generating explanation...</div>}
              {aiExplanation && <p className="text-gray-300 leading-relaxed whitespace-pre-wrap">{aiExplanation}</p>}
           </div>

          {/* Remediation */}
          <div>
            <h3 className="font-semibold text-lg text-cyan-400 mb-2">How to Fix It</h3>
            <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-700">
                <p className="font-semibold text-gray-200 mb-3">Recommended Action: <span className="font-bold text-yellow-300">{finding.remediation.action}</span></p>
                <ol className="list-decimal list-inside space-y-2 text-gray-300">
                    {finding.remediation.steps.map((step, index) => <li key={index}>{step}</li>)}
                </ol>
                {finding.remediation.path && (
                    <div className="mt-3 pt-3 border-t border-gray-700">
                        <p className="text-sm text-gray-400">
                            <span className="font-semibold">Quick Path:</span> <code className="bg-gray-700 text-cyan-300 px-2 py-1 rounded">{finding.remediation.path}</code>
                        </p>
                    </div>
                )}
            </div>
          </div>
        </div>

        <footer className="p-4 bg-gray-900/50 border-t border-gray-700 sticky bottom-0">
          <div className="flex justify-end items-center">
            {isFixed ? (
                <div className="flex items-center space-x-2 text-green-400 font-semibold">
                    <ICONS.shieldCheck className="w-6 h-6" />
                    <span>This issue has been resolved.</span>
                </div>
            ) : (
                <button
                    onClick={() => onFix(finding.id)}
                    className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 flex items-center space-x-2"
                >
                    <span>Fix with One Click (Simulated)</span>
                </button>
            )}
            
          </div>
          <p className="text-xs text-gray-500 text-right mt-2">One-click fix is a simulation for this web demo and does not alter system settings.</p>
        </footer>
      </div>
    </div>
  );
};

export default RiskDetailModal;
