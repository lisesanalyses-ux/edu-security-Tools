
import React from 'react';

interface ScoreIndicatorProps {
  score: number;
}

const ScoreIndicator: React.FC<ScoreIndicatorProps> = ({ score }) => {
  const getScoreColor = () => {
    if (score >= 90) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getTrackColor = () => {
    if (score >= 90) return 'stroke-green-400/30';
    if (score >= 60) return 'stroke-yellow-400/30';
    return 'stroke-red-400/30';
  };
  
  const getProgressColor = () => {
    if (score >= 90) return 'stroke-green-400';
    if (score >= 60) return 'stroke-yellow-400';
    return 'stroke-red-400';
  }

  const circumference = 2 * Math.PI * 52; // 2 * pi * radius
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="relative flex items-center justify-center w-48 h-48 mx-auto">
      <svg className="w-full h-full" viewBox="0 0 120 120">
        <circle
          className={getTrackColor()}
          strokeWidth="10"
          stroke="currentColor"
          fill="transparent"
          r="52"
          cx="60"
          cy="60"
        />
        <circle
          className={getProgressColor()}
          strokeWidth="10"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          stroke="currentColor"
          fill="transparent"
          r="52"
          cx="60"
          cy="60"
          transform="rotate(-90 60 60)"
          style={{ transition: 'stroke-dashoffset 0.5s ease-in-out' }}
        />
      </svg>
      <div className={`absolute text-5xl font-bold ${getScoreColor()}`}>
        {score}
      </div>
    </div>
  );
};

export default ScoreIndicator;
