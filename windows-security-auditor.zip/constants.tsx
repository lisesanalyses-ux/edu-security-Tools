
import React from 'react';
import { SecurityFinding, RiskCategory, FindingStatus } from './types';

export const MOCK_FINDINGS: SecurityFinding[] = [
  {
    id: '1',
    title: 'Guest Account is enabled',
    category: RiskCategory.USER_ACCOUNTS,
    status: FindingStatus.RISK,
    severity: 'High',
    description: 'The Guest account allows unauthenticated network users to log on as a Guest without a password.',
    architecture: 'An enabled Guest account is a well-known security risk as it provides a potential entry point for unauthorized users. It could be exploited to access non-critical files and potentially escalate privileges.',
    reference: {
      name: 'CIS Benchmark for Windows 10',
      url: 'https://www.cisecurity.org/cis-benchmarks/',
    },
    remediation: {
      action: 'DISABLE Guest Account',
      steps: [
        'Open Local Users and Groups (lusrmgr.msc).',
        'Navigate to the "Users" folder.',
        'Right-click the "Guest" account and select "Properties".',
        'Check the "Account is disabled" box and click OK.',
      ],
      path: 'lusrmgr.msc > Users > Guest',
    },
  },
  {
    id: '2',
    title: 'Storing passwords using reversible encryption',
    category: RiskCategory.USER_ACCOUNTS,
    status: FindingStatus.RISK,
    severity: 'Critical',
    description: 'This policy setting determines whether Active Directory Domain Services stores passwords using reversible encryption.',
    architecture: 'Reversible encryption provides less protection than one-way hashing. An attacker who gains access to the SAM/NTDS.dit database can easily decrypt these passwords and use them to compromise other systems.',
    reference: {
      name: 'Microsoft Security Baselines',
      url: 'https://docs.microsoft.com/en-us/windows/security/threat-protection/windows-security-baselines',
    },
    remediation: {
      action: 'DISABLE reversible encryption storage',
      steps: [
        'Open Group Policy Management Editor (gpedit.msc).',
        'Navigate to Computer Configuration > Windows Settings > Security Settings > Account Policies > Password Policy.',
        'Double-click "Store passwords using reversible encryption" and set it to "Disabled".',
      ],
      path: 'gpedit.msc > ... > Password Policy',
    },
  },
  {
    id: '3',
    title: 'NetBIOS over TCP/IP is enabled',
    category: RiskCategory.NETWORK,
    status: FindingStatus.RISK,
    severity: 'High',
    description: 'NetBIOS is a legacy protocol used for name resolution. It is noisy and can be exploited for information gathering and attacks.',
    architecture: 'Enabling NetBIOS over TCP/IP exposes system information (like computer name, domain) over the network. It is vulnerable to sniffing and spoofing attacks, and was the entry point for exploits like EternalBlue (used by WannaCry).',
    reference: {
      name: 'NSA Cyber Security Guidance',
      url: 'https://www.nsa.gov/cybersecurity-guidance',
    },
    remediation: {
      action: 'DISABLE NetBIOS over TCP/IP',
      steps: [
        'Open Network Connections control panel.',
        'Right-click your network adapter and select Properties.',
        'Select "Internet Protocol Version 4 (TCP/IPv4)" and click Properties.',
        'Click Advanced > WINS tab.',
        'Select "Disable NetBIOS over TCP/IP" and click OK.',
      ],
      path: 'ncpa.cpl > Adapter Properties > TCP/IPv4 > Advanced > WINS',
    },
  },
  {
    id: '4',
    title: 'User Account Control (UAC) is on a low setting',
    category: RiskCategory.PROTECTION,
    status: FindingStatus.RISK,
    severity: 'Medium',
    description: 'UAC helps prevent malicious software from making unauthorized changes to your computer.',
    architecture: 'A lowered UAC setting, especially "Never notify", allows malicious programs to elevate their privileges silently in the background without user consent. This bypasses a critical defense-in-depth security layer.',
    reference: {
      name: 'Microsoft UAC Documentation',
      url: 'https://docs.microsoft.com/en-us/windows/security/identity-protection/user-account-control/user-account-control-overview',
    },
    remediation: {
      action: 'ENABLE UAC to recommended level',
      steps: [
        'Open "User Account Control settings" from the Start Menu.',
        'Move the slider up to the second option from the top: "Notify me only when apps try to make changes to my computer (default)".',
        'Click OK and confirm the change.',
      ],
      path: 'Control Panel > User Accounts > Change User Account Control settings',
    },
  },
  {
    id: '5',
    title: 'Minimum password length is less than 12 characters',
    category: RiskCategory.USER_ACCOUNTS,
    status: FindingStatus.FIXED,
    severity: 'High',
    description: 'A short minimum password length makes user accounts vulnerable to brute-force and dictionary attacks.',
     architecture: 'Passwords under 12 characters can be cracked relatively quickly with modern hardware. Enforcing a longer minimum length significantly increases the time and computational resources required for an attacker to succeed.',
    reference: {
      name: 'NIST Password Guidelines',
      url: 'https://pages.nist.gov/800-63-3/sp800-63b.html',
    },
    remediation: {
      action: 'SET minimum password length to 12 or more',
      steps: [
        'Open Group Policy Management Editor (gpedit.msc).',
        'Navigate to Computer Configuration > Windows Settings > Security Settings > Account Policies > Password Policy.',
        'Set "Minimum password length" to 12 or higher.',
      ],
      path: 'gpedit.msc > ... > Password Policy',
    },
  },
   {
    id: '6',
    title: 'Windows AutoUpdate is disabled',
    category: RiskCategory.SYSTEM,
    status: FindingStatus.RISK,
    severity: 'Critical',
    description: 'Automatic updates are disabled, leaving the system vulnerable to newly discovered exploits.',
     architecture: 'Disabling automatic updates means critical security patches are not applied in a timely manner. This creates a window of opportunity for attackers to exploit known vulnerabilities for which patches are already available.',
    reference: {
      name: 'Microsoft Update Policy',
      url: 'https://docs.microsoft.com/en-us/windows/deployment/update/waas-manage-updates-wufb',
    },
    remediation: {
      action: 'ENABLE Automatic Updates',
      steps: [
        'Open Settings > Update & Security > Windows Update.',
        'Click on "Advanced options".',
        'Ensure that automatic updates are turned on.',
      ],
      path: 'ms-settings:windowsupdate',
    },
  },
];

export const ICONS = {
    shieldCheck: (props: React.SVGProps<SVGSVGElement>) => (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.286Zm0 13.036h.008v.016h-.008v-.016Z" />
        </svg>
    ),
    shieldExclamation: (props: React.SVGProps<SVGSVGElement>) => (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" />
        </svg>
    ),
    arrowRight: (props: React.SVGProps<SVGSVGElement>) => (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
        </svg>
    ),
    xMark: (props: React.SVGProps<SVGSVGElement>) => (
       <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
        </svg>
    ),
    sparkles: (props: React.SVGProps<SVGSVGElement>) => (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456Z" />
      </svg>
    )
}