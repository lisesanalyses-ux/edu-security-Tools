
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real app, you might want to handle this more gracefully.
  // For this environment, we assume the key is always available.
  console.warn("API_KEY environment variable not set. Gemini features will not work.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const getEnhancedExplanation = async (findingTitle: string): Promise<string> => {
  if (!API_KEY) {
    return "Gemini AI is not configured. Please set the API_KEY environment variable.";
  }

  try {
    const prompt = `
      You are a senior cybersecurity analyst. Explain the following Windows security risk in simple, clear terms for a non-technical user. 
      Focus on the real-world impact and why fixing it is important. Keep the explanation to 2-3 concise paragraphs.
      
      Risk: "${findingTitle}"
    `;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    return response.text;
  } catch (error) {
    console.error("Error fetching explanation from Gemini:", error);
    return "Could not get an explanation from the AI. The service may be temporarily unavailable.";
  }
};
