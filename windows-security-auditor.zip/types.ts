
export enum RiskCategory {
  USER_ACCOUNTS = 'User Accounts & Authentication',
  NETWORK = 'Network & Firewall',
  SYSTEM = 'System Integrity & Updates',
  PROTECTION = 'Endpoint Protection',
}

export enum FindingStatus {
  RISK = 'risk',
  FIXED = 'fixed',
}

export interface SecurityFinding {
  id: string;
  title: string;
  category: RiskCategory;
  status: FindingStatus;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  description: string;
  architecture: string;
  reference: {
    name: string;
    url: string;
  };
  remediation: {
    action: string;
    steps: string[];
    command?: string;
    path?: string;
  };
}
